<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='epp.package.cpp' timestamp='1741251017632'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/home/jenkins/agent/workspace/epp_master/packages/org.eclipse.epp.package.cpp.product/target/products/epp.package.cpp/win32/win32/x86_64/eclipse'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/home/jenkins/agent/workspace/epp_master/packages/org.eclipse.epp.package.cpp.product/target/products/epp.package.cpp/win32/win32/x86_64/eclipse'/>
  </properties>
</profile>
